let text = document.getElementById('text');
let chem_back1 = document.getElementById('chem_back1');
let chem_back4= document.getElementById('chem_back4');
let chem_back5 = document.getElementById('chem_back5');

window.addEventListener('scroll', () => {
    let value = window.scrollY;

    
});